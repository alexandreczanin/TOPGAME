﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TOPGames
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void usúarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUsuario usu = new FormUsuario();
            usu.Show();
        }

        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCliente cli = new FormCliente();
            cli.Show();
        }

        private void artigosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormProduto pro = new FormProduto();
            pro.Show();
        }

        private void locaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormJogo jog = new FormJogo();
            jog.Show();
        }

        private void vendaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormVenda ven = new FormVenda();
            ven.Show();
        }

        private void alugarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAluguel alu = new FormAluguel();
            alu.Show();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pbxCadUser_Click(object sender, EventArgs e)
        {
            FormUsuario usu = new FormUsuario();
            usu.Show();
        }

        private void PbxCadCliente_Click(object sender, EventArgs e)
        {
            FormCliente cli = new FormCliente();
            cli.Show();
        }

        private void pbxCadJogo_Click(object sender, EventArgs e)
        {
            FormJogo jog = new FormJogo();
            jog.Show();
        }

        private void pbxCadProduto_Click(object sender, EventArgs e)
        {
            FormProduto pro = new FormProduto();
            pro.Show();
        }

        private void pbxVenda_Click(object sender, EventArgs e)
        {
            FormVenda ven = new FormVenda();
            ven.Show();
        }

        private void pbxAlugar_Click(object sender, EventArgs e)
        {
            FormAluguel alu = new FormAluguel();
            alu.Show();
        }
    }
}
